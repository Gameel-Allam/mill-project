const Dashboard = () => {
  return (
    <div>
      main
    </div>
  )
}

export default Dashboard
