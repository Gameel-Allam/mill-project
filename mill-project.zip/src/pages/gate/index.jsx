import GateTable from "./components/GateTable";

const Gateindex = () => {
  return (
    <div>
      <GateTable />
    </div>
  );
};

export default Gateindex;
