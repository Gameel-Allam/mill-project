// import Steps from "./components/Steps";
// import Stepper from "./components/stepper";

const index = () => {
  return (
    <div>
      main
    </div>
  )
};

export default index;
