// import CollectionPro from "../collectionCenterPro/CollectionPro";
// import CollectionPro from "../collectionCenterPro/CollectionPro";
import SessionPro from "../sessionPro/SessionPro";
// import SessionPro from "../sessionPro/SessionPro";
// import SessionPro from "../sessionPro/SessionPro";

const index = () => {
  return (
    <>
      {/* <SessionPro /> */}
    </>
  )


};

export default index;
