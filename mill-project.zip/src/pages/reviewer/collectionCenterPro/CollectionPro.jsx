import CreateCollectionPro from "./components/CreateCollectionPro"

const CollectionPro = () => {
    return (
        <>
            <CreateCollectionPro />
        </>
    )
}

export default CollectionPro