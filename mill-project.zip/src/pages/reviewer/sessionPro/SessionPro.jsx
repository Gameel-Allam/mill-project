import CreateSessionPro from "./components/CreateSessionPro"

const SessionPro = () => {
    return (
        <>
            <CreateSessionPro />
        </>
    )
}

export default SessionPro
