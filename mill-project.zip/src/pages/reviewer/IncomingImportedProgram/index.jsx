import CreateIncomingPro from "./components/CreateIncomingPro"

const IncomingPro = () => {
    return (
        <>
            <CreateIncomingPro />
        </>
    )
}

export default IncomingPro
