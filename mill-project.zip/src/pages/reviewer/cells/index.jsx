// import CellCard from "./components/Grid/CellCard";
import Grid from "../../manager/cells/components/Grid/Grid";
const index = () => {
  return <div>
    <Grid />
  </div>;
};

export default index;
