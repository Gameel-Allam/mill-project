// import styles from "./Cells.Module.scss";
import CellsCard from "./CellsCard";
const Grid = () => {
  return (
    <div className={`container`}>
        <div className="row">
        <CellsCard/>
        </div>
    </div>
  )
}

export default Grid
