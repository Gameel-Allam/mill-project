// import CellsCard from "./components/Grid/CellsCard";
import Grid from "./components/Grid/Grid";
// import SiloIcon from "./components/Grid/SiloIcon";
import styles from "./main.module.scss";

const index = () => {
  return <div className={styles.main__index}>
   <Grid/>
  </div>;
};

export default index;
