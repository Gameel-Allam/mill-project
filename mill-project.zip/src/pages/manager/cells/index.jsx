// import CellsCard from "./components/Grid/CellsCard";
import Grid from "./components/Grid/Grid";
// import SiloIcon from "./components/Grid/SiloIcon";

const index = () => {
  return <div>
   <Grid/>
  </div>;
};

export default index;
