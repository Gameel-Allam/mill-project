// import { Grid } from "@mui/material";
// import AllReport from "./components/AllReport";
// import CellsReports from "./components/CellsReports";
// import WheatReport from "./components/WheatReport";

import Grid from "./components/Grid/Grid";

const index = () => {
  return(
      <Grid/>
  )
};

export default index;
