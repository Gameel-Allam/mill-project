import CellCard from "./components/Grid/CellCard";

const index = () => {
  return <div>
    <CellCard/>
  </div>;
};

export default index;
