const CellCard = () => {
  return (
    <div>
      cell card
    </div>
  )
}

export default CellCard
