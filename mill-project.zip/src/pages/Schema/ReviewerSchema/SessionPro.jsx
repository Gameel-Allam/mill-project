import * as Yup from 'yup';
export const SessionValidation = Yup.object().shape({

})