import * as Yup from 'yup';
export const CollectionCenterValidation = Yup.object().shape({

})