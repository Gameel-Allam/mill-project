import Mill from "./components/Mill"

const TotalMileQuan = () => {
  return (
    <div>
      <Mill />
    </div>
  )
}

export default TotalMileQuan