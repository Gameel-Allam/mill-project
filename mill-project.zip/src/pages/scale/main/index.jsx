import Scaletable from "./components/ScaleTable"

const Index = () => {
  return (
    <>
      <Scaletable/>
    </>
  )
}

export default Index
