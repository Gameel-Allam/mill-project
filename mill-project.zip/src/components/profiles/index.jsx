import Profile from "./components/Profile"

const DynamicProfile = () => {
    return (
        <div>
            <Profile />
        </div>
    )
}

export default DynamicProfile